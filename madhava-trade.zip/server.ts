import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Market Data Proxy
  // This helps avoid CORS and hides the API key from the client
  app.get("/api/market/quote", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });

    const apiKey = process.env.MARKET_API_KEY;
    
    // If no API key is set, we use Yahoo Finance as a free source for real-time-ish data
    if (!apiKey || apiKey === "YOUR_MARKET_API_KEY") {
      try {
        // Try NSE first, then BSE
        const nseSymbol = `${symbol}.NS`;
        const yfUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${nseSymbol}?interval=1m&range=1d`;
        const response = await fetch(yfUrl);
        const data = await response.json();
        
        const result = data?.chart?.result?.[0];
        const meta = result?.meta;
        
        if (meta && meta.regularMarketPrice) {
          return res.json({
            symbol: symbol,
            price: meta.regularMarketPrice,
            change: (meta.regularMarketPrice - meta.chartPreviousClose).toFixed(2),
            changePercent: (((meta.regularMarketPrice - meta.chartPreviousClose) / meta.chartPreviousClose) * 100).toFixed(2) + "%",
            source: "live"
          });
        }
        
        // Fallback to simulation if YF fails
        return res.json({ 
          symbol, 
          price: (Math.random() * 1000 + 500).toFixed(2), 
          change: (Math.random() * 2 - 1).toFixed(2),
          source: "simulation" 
        });
      } catch (error) {
        return res.json({ 
          symbol, 
          price: (Math.random() * 1000 + 500).toFixed(2), 
          change: (Math.random() * 2 - 1).toFixed(2),
          source: "simulation" 
        });
      }
    }

    try {
      // Example using Alpha Vantage (you can adapt to any provider)
      const response = await fetch(`https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`);
      const data = await response.json();
      
      const quote = data["Global Quote"];
      if (quote) {
        res.json({
          symbol: quote["01. symbol"],
          price: quote["05. price"],
          change: quote["09. change"],
          changePercent: quote["10. change percent"],
          source: "live"
        });
      } else {
        res.status(404).json({ error: "Symbol not found or API limit reached" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market data" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
