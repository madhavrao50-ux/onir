import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  LayoutDashboard, 
  ClipboardList, 
  Briefcase, 
  TrendingUp, 
  Wallet, 
  Settings, 
  Search, 
  RefreshCw, 
  X, 
  ArrowUpRight, 
  ArrowDownRight,
  Info,
  CheckCircle2,
  AlertCircle,
  LineChart as ChartIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import TradingViewChart from './components/TradingViewChart';

// --- Types ---
interface Stock {
  t: string; // Ticker
  n: string; // Name
  s: string; // Sector
  base: number;
}

interface Order {
  id: string;
  t: string;
  qty: number;
  p: number;
  mode: 'BUY' | 'SELL';
  type: string;
  prod: string;
  status: 'COMPLETE' | 'PENDING';
  time: string;
  pnl?: number;
}

interface Holding {
  t: string;
  qty: number;
  avgPrice: number;
  name: string;
}

const UNIVERSE: Record<string, Stock[]> = {
  nse: [
    {t:'RELIANCE', n:'Reliance Industries', s:'Energy',   base:2890},
    {t:'TCS',      n:'Tata Consultancy',    s:'IT',        base:4015},
    {t:'HDFCBANK', n:'HDFC Bank',           s:'Banking',   base:1543},
    {t:'INFY',     n:'Infosys Ltd.',         s:'IT',        base:1758},
    {t:'ICICIBANK',n:'ICICI Bank',           s:'Banking',   base:1089},
    {t:'SBIN',     n:'State Bank of India',  s:'Banking',   base:795},
    {t:'TATAMOTORS',n:'Tata Motors',         s:'Auto',      base:972},
    {t:'WIPRO',    n:'Wipro Ltd.',           s:'IT',        base:462},
    {t:'ITC',      n:'ITC Limited',          s:'FMCG',      base:445},
    {t:'BHARTIARTL',n:'Bharti Airtel',       s:'Telecom',   base:1680},
  ],
  bank: [
    {t:'HDFCBANK', n:'HDFC Bank',       s:'Banking', base:1543},
    {t:'ICICIBANK',n:'ICICI Bank',       s:'Banking', base:1089},
    {t:'SBIN',     n:'SBI',             s:'Banking', base:795},
    {t:'KOTAKBANK',n:'Kotak Bank',       s:'Banking', base:1820},
    {t:'AXISBANK', n:'Axis Bank',        s:'Banking', base:1045},
  ],
  it: [
    {t:'TCS',     n:'Tata Consultancy', s:'IT', base:4015},
    {t:'INFY',    n:'Infosys',           s:'IT', base:1758},
    {t:'WIPRO',   n:'Wipro',             s:'IT', base:462},
    {t:'HCLTECH', n:'HCL Technologies',  s:'IT', base:1680},
    {t:'TECHM',   n:'Tech Mahindra',     s:'IT', base:1520},
  ]
};

// --- Helper: Format INR ---
const inr = (n: number, d = 2) => {
  if (isNaN(n)) return '₹—';
  const a = Math.abs(n);
  let s = a >= 10000000 ? (a / 10000000).toFixed(2) + 'Cr' : 
          a >= 100000 ? (a / 100000).toFixed(2) + 'L' : 
          a.toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });
  return (n < 0 ? '-' : '') + '₹' + s;
};

export default function App() {
  // --- State ---
  const [cash, setCash] = useState(500000);
  const [holdings, setHoldings] = useState<Record<string, Holding>>({});
  const [orders, setOrders] = useState<Order[]>([]);
  const [realised, setRealised] = useState(0);
  const [prices, setPrices] = useState<Record<string, number>>({});
  const [prevClose, setPrevClose] = useState<Record<string, number>>({});
  const [activePage, setActivePage] = useState('dashboard');
  const [wlCat, setWlCat] = useState('nse');
  const [search, setSearch] = useState('');
  const [owTicker, setOwTicker] = useState<string | null>(null);
  const [owMode, setOwMode] = useState<'buy' | 'sell'>('buy');
  const [owQty, setOwQty] = useState(1);
  const [owPrice, setOwPrice] = useState(0);
  const [owType, setOwType] = useState('Market');
  const [owProd, setOwProd] = useState('CNC');
  const [notifs, setNotifs] = useState<{id: string, title: string, body: string, type: string}[]>([]);
  const [marketOpen, setMarketOpen] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [apiProvider, setApiProvider] = useState('Alpha Vantage (Global)');
  const [isSavingKey, setIsSavingKey] = useState(false);
  const [selectedTicker, setSelectedTicker] = useState('RELIANCE');

  // --- Live Data Fetching ---
  const fetchLiveQuote = useCallback(async (symbol: string) => {
    try {
      const res = await fetch(`/api/market/quote?symbol=${symbol}`);
      const data = await res.json();
      if (data.price) {
        setPrices(prev => ({ ...prev, [symbol]: parseFloat(data.price) }));
        if (data.source === 'live') {
          setIsSimulating(false);
        }
      }
    } catch (err) {
      console.error('Failed to fetch quote', err);
    }
  }, []);

  const handleSaveKey = async () => {
    setIsSavingKey(true);
    // In a real app, we might send this to the server to verify or store in a session/db
    // For this demo, we'll just simulate the "saving" and then try to fetch a quote
    setTimeout(() => {
      setIsSavingKey(false);
      addNotif('API Key Saved', `Successfully connected to ${apiProvider}. Switching to live data...`);
      setIsSimulating(false);
      // Try to fetch a few quotes to verify
      UNIVERSE.nse.slice(0, 3).forEach(s => fetchLiveQuote(s.t));
    }, 1000);
  };

  // --- Initial Prices ---
  useEffect(() => {
    const initialPrices: Record<string, number> = {};
    const initialPrevClose: Record<string, number> = {};
    const allStocks = Object.values(UNIVERSE).flat();
    
    allStocks.forEach(s => {
      if (!initialPrices[s.t]) {
        initialPrices[s.t] = s.base;
        initialPrevClose[s.t] = s.base;
      }
    });
    setPrices(initialPrices);
    setPrevClose(initialPrevClose);

    // Fetch real quotes for all stocks on mount
    const fetchAllQuotes = async () => {
      const uniqueTickers = Array.from(new Set(allStocks.map(s => s.t)));
      for (const ticker of uniqueTickers) {
        await fetchLiveQuote(ticker);
        // Small delay to avoid rate limiting
        await new Promise(r => setTimeout(r, 100));
      }
    };
    fetchAllQuotes();

    // Periodic update for live quotes (every 5 minutes)
    const liveInt = setInterval(() => {
      if (!isSimulating) {
        fetchAllQuotes();
      }
    }, 5 * 60 * 1000);

    // Check market status
    const checkMkt = () => {
      const ist = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
      const h = ist.getHours(), m = ist.getMinutes(), d = ist.getDay();
      const open = d >= 1 && d <= 5 && (h > 9 || (h === 9 && m >= 15)) && (h < 15 || (h === 15 && m <= 30));
      setMarketOpen(open);
    };
    checkMkt();
    const mktInt = setInterval(checkMkt, 60000);
    return () => {
      clearInterval(mktInt);
      clearInterval(liveInt);
    };
  }, [fetchLiveQuote, isSimulating]);

  // --- Simulation Tick ---
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setPrices(prev => {
        const next = { ...prev };
        const mktDrift = (Math.random() - 0.498) * 0.0008;
        Object.keys(next).forEach(ticker => {
          const p = next[ticker];
          const stockDrift = (Math.random() - 0.498) * 0.0015;
          const totalMove = (mktDrift * 0.4 + stockDrift) * p;
          next[ticker] = parseFloat(Math.max(p * 0.5, p + totalMove).toFixed(2));
        });
        return next;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [isSimulating]);

  // --- Notifications ---
  const addNotif = useCallback((title: string, body: string, type = 'success') => {
    const id = Math.random().toString(36).substring(7);
    setNotifs(prev => [...prev, { id, title, body, type }]);
    setTimeout(() => {
      setNotifs(prev => prev.filter(n => n.id !== id));
    }, 4500);
  }, []);

  // --- Order Logic ---
  const openOW = (t: string, mode: 'buy' | 'sell' = 'buy') => {
    setOwTicker(t);
    setSelectedTicker(t);
    setOwMode(mode);
    setOwQty(1);
    setOwPrice(prices[t] || 0);
    setOwType('Market');
    setOwProd('CNC');
  };

  const submitOrder = () => {
    if (!owTicker) return;
    const p = prices[owTicker];
    if (!p) return addNotif('Price unavailable', 'Prices still loading', 'error');
    
    const currentPrice = owType === 'Market' ? p : owPrice;
    const cost = owQty * currentPrice;

    if (owMode === 'buy') {
      if (cost > cash) return addNotif('Insufficient funds', `Need ${inr(cost)}, have ${inr(cash)}`, 'error');
      setCash(prev => prev - cost);
      setHoldings(prev => {
        const next = { ...prev };
        if (!next[owTicker]) {
          const s = Object.values(UNIVERSE).flat().find(x => x.t === owTicker);
          next[owTicker] = { qty: 0, avgPrice: 0, name: s?.n || owTicker };
        }
        const h = next[owTicker];
        const nq = h.qty + owQty;
        h.avgPrice = ((h.qty * h.avgPrice) + cost) / nq;
        h.qty = nq;
        return next;
      });
      setOrders(prev => [{
        id: Math.random().toString(36).substring(7),
        t: owTicker,
        qty: owQty,
        p: currentPrice,
        mode: 'BUY',
        type: owType,
        prod: owProd,
        status: 'COMPLETE',
        time: new Date().toISOString()
      }, ...prev]);
      addNotif(`✓ BUY ${owTicker}`, `${owQty} × ₹${currentPrice.toFixed(2)} = ${inr(cost)}`);
    } else {
      const h = holdings[owTicker];
      if (!h || h.qty < owQty) return addNotif('Insufficient holdings', `Have ${h?.qty || 0} shares`, 'error');
      const pnl = (currentPrice - h.avgPrice) * owQty;
      setCash(prev => prev + cost);
      setRealised(prev => prev + pnl);
      setHoldings(prev => {
        const next = { ...prev };
        next[owTicker].qty -= owQty;
        if (next[owTicker].qty === 0) delete next[owTicker];
        return next;
      });
      setOrders(prev => [{
        id: Math.random().toString(36).substring(7),
        t: owTicker,
        qty: owQty,
        p: currentPrice,
        pnl,
        mode: 'SELL',
        type: owType,
        prod: owProd,
        status: 'COMPLETE',
        time: new Date().toISOString()
      }, ...prev]);
      addNotif(`✓ SELL ${owTicker}`, `P&L: ${pnl >= 0 ? '+' : ''}${inr(pnl)} | ${owQty} × ₹${currentPrice.toFixed(2)}`, pnl < 0 ? 'error' : 'success');
    }
    setOwTicker(null);
  };

  // --- Derived State ---
  const unrealised = useMemo(() => {
    return Object.keys(holdings).reduce((acc, t) => {
      const h = holdings[t];
      const p = prices[t] || h.avgPrice;
      return acc + (p - h.avgPrice) * h.qty;
    }, 0);
  }, [holdings, prices]);

  const totalEquity = cash + Object.keys(holdings).reduce((acc, t) => {
    const h = holdings[t];
    return acc + h.qty * (prices[t] || h.avgPrice);
  }, 0);

  const filteredWL = UNIVERSE[wlCat].filter(s => 
    !search || s.t.toLowerCase().includes(search.toLowerCase()) || s.n.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-screen bg-[#f5f5f5] text-[#1a1a1a] font-sans overflow-hidden">
      {/* --- Top Bar --- */}
      <div className="h-9 bg-white border-b border-[#e8e8e8] flex items-center px-4 gap-4 flex-shrink-0 z-50">
        <div className="flex gap-4 font-mono text-[11px]">
          <div className="flex items-center gap-1.5">
            <span className="text-[#7c7c7c] font-medium">NIFTY 50</span>
            <span className="text-[#26a69a] font-semibold">22,500.00</span>
            <span className="text-[#26a69a]">+0.45%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#7c7c7c] font-medium">SENSEX</span>
            <span className="text-[#26a69a] font-semibold">74,200.00</span>
            <span className="text-[#26a69a]">+0.42%</span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono ${isSimulating ? 'bg-emerald-50 text-emerald-600' : 'bg-orange-50 text-orange-600'}`}>
            <div className={`w-1.5 h-1.5 rounded-full ${isSimulating ? 'bg-emerald-500 animate-pulse' : 'bg-orange-500'}`} />
            {isSimulating ? 'SIMULATION' : 'LIVE DATA'}
          </div>
          <span className={`text-[11px] font-mono ${marketOpen ? 'text-emerald-600' : 'text-gray-400'}`}>
            {marketOpen ? '● Market Open' : '○ Market Closed'}
          </span>
          <button 
            onClick={() => setIsSimulating(!isSimulating)}
            className="text-[11px] px-2 py-0.5 border border-gray-200 rounded hover:bg-gray-50 transition-colors"
          >
            <RefreshCw size={10} className="inline mr-1" />
            {isSimulating ? 'Switch to Live' : 'Switch to Sim'}
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* --- Sidebar / Watchlist --- */}
        <div className="w-[280px] bg-white border-r border-[#e8e8e8] flex flex-col flex-shrink-0">
          <div className="p-3 border-b border-[#e8e8e8]">
            <div className="flex gap-1 mb-2">
              {['nse', 'bank', 'it'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setWlCat(cat)}
                  className={`px-2.5 py-1 rounded text-[11px] uppercase tracking-wider transition-colors ${wlCat === cat ? 'bg-[#e84141] text-white' : 'text-[#7c7c7c] hover:bg-gray-100'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <div className="flex items-center bg-[#f9f9f9] border border-[#e8e8e8] rounded px-2 py-1.5 gap-2">
              <Search size={14} className="text-[#b0b0b0]" />
              <input
                type="text"
                placeholder="Search stocks..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-transparent outline-none text-xs w-full"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filteredWL.map(s => {
              const p = prices[s.t];
              const pc = prevClose[s.t] || s.base;
              const chg = p ? ((p - pc) / pc) * 100 : 0;
              const isUp = chg >= 0;
              return (
                <div 
                  key={s.t}
                  onClick={() => { setSelectedTicker(s.t); setActivePage('chart'); }}
                  className="group relative flex items-center px-3 h-12 border-b border-gray-50 cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <span className="block font-medium text-[13px]">{s.t}</span>
                    <span className="text-[10px] text-[#b0b0b0] font-mono uppercase tracking-tight">NSE · {s.s}</span>
                  </div>
                  <div className="text-right font-mono">
                    <div className={`text-[13px] font-medium ${isUp ? 'text-[#26a69a]' : 'text-[#ef5350]'}`}>
                      {p ? p.toLocaleString('en-IN', { minimumFractionDigits: 2 }) : '—'}
                    </div>
                    <div className={`text-[10px] ${isUp ? 'text-[#26a69a]' : 'text-[#ef5350]'}`}>
                      {chg ? `${isUp ? '+' : ''}${chg.toFixed(2)}%` : '—'}
                    </div>
                  </div>
                  <div className="absolute right-0 inset-y-0 hidden group-hover:flex items-center bg-gradient-to-l from-gray-50 via-gray-50 to-transparent pl-6 pr-2 gap-1">
                    <button 
                      onClick={(e) => { e.stopPropagation(); openOW(s.t, 'buy'); }}
                      className="bg-[#26a69a] text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm hover:brightness-110"
                    >
                      B
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); openOW(s.t, 'sell'); }}
                      className="bg-[#ef5350] text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm hover:brightness-110"
                    >
                      S
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* --- Main Content --- */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Navbar */}
          <div className="h-11 bg-white border-b border-[#e8e8e8] flex items-center px-5 flex-shrink-0">
            <div className="flex items-center gap-1.5 mr-6">
              <div className="w-5 h-5 bg-[#e84141] [clip-path:polygon(50%_0%,100%_100%,0%_100%)]" />
              <span className="text-[15px] font-bold text-[#e84141] tracking-tight uppercase">Madhava Trade</span>
            </div>
            <div className="flex h-full">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={14} /> },
                { id: 'orders', label: 'Orders', icon: <ClipboardList size={14} /> },
                { id: 'holdings', label: 'Holdings', icon: <Briefcase size={14} /> },
                { id: 'positions', label: 'Positions', icon: <TrendingUp size={14} /> },
                { id: 'chart', label: 'Chart', icon: <ChartIcon size={14} /> },
                { id: 'funds', label: 'Funds', icon: <Wallet size={14} /> },
                { id: 'setup', label: 'Live Data', icon: <Settings size={14} />, color: 'text-orange-500' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActivePage(item.id)}
                  className={`px-4 flex items-center gap-2 text-[13px] transition-all relative ${activePage === item.id ? 'text-[#e84141] font-semibold' : 'text-[#7c7c7c] hover:text-[#1a1a1a]'}`}
                >
                  {item.icon}
                  {item.label}
                  {activePage === item.id && (
                    <motion.div layoutId="nav-underline" className="absolute bottom-0 left-4 right-4 h-0.5 bg-[#e84141] rounded-full" />
                  )}
                </button>
              ))}
            </div>
            <div className="ml-auto flex items-center gap-4 text-xs text-[#7c7c7c]">
              <span>Hi, <strong>Trader</strong></span>
              <div className="h-4 w-px bg-gray-200" />
              <span>Equity: <strong className="text-[#1a1a1a] font-mono">{inr(cash, 0)}</strong></span>
            </div>
          </div>

          {/* Page Content */}
          <div className="flex-1 overflow-y-auto p-5">
            <AnimatePresence mode="wait">
              {activePage === 'dashboard' && (
                <motion.div 
                  key="dashboard"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="max-w-4xl space-y-6"
                >
                  <h2 className="text-xl font-light">Hi, <strong>Trader</strong> 👋</h2>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-4 shadow-sm">
                      <div className="flex items-center gap-2 text-[#7c7c7c] text-xs font-medium mb-4">
                        <Wallet size={14} />
                        EQUITY
                      </div>
                      <div className="text-3xl font-light font-mono text-emerald-600 mb-1">{inr(cash, 0)}</div>
                      <div className="text-[11px] text-[#7c7c7c] mb-4">Margin available</div>
                      <div className="space-y-2 border-t border-gray-50 pt-3">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-[#7c7c7c]">Margins used</span>
                          <span className="font-mono font-medium">{inr((Object.values(holdings) as Holding[]).reduce((a, h) => a + h.qty * h.avgPrice, 0), 0)}</span>
                        </div>
                        <div className="flex justify-between text-[11px]">
                          <span className="text-[#7c7c7c]">Opening balance</span>
                          <span className="font-mono font-medium">₹5,00,000</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-4 shadow-sm">
                      <div className="flex items-center gap-2 text-[#7c7c7c] text-xs font-medium mb-4">
                        <TrendingUp size={14} />
                        P&L
                      </div>
                      <div className={`text-2xl font-semibold font-mono mb-1 ${(realised + unrealised) >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                        {(realised + unrealised) >= 0 ? '+' : ''}{inr(realised + unrealised)}
                      </div>
                      <div className="text-[11px] text-[#7c7c7c] mb-4">Realised + Unrealised</div>
                      <div className="space-y-2 border-t border-gray-50 pt-3">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-[#7c7c7c]">Realised</span>
                          <span className={`font-mono font-medium ${realised >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>{inr(realised)}</span>
                        </div>
                        <div className="flex justify-between text-[11px]">
                          <span className="text-[#7c7c7c]">Unrealised</span>
                          <span className={`font-mono font-medium ${unrealised >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>{inr(unrealised)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-2 bg-white border border-[#e8e8e8] rounded-lg p-4 shadow-sm">
                      <div className="flex items-center gap-2 text-[#7c7c7c] text-xs font-medium mb-4">
                        <Briefcase size={14} />
                        HOLDINGS ({Object.keys(holdings).length})
                      </div>
                      <div className="space-y-3">
                        {Object.keys(holdings).length === 0 ? (
                          <div className="text-center py-6 text-gray-400 text-xs">No holdings. Buy stocks to see them here.</div>
                        ) : (
                          Object.keys(holdings).slice(0, 5).map(t => {
                            const h = holdings[t];
                            const p = prices[t] || h.avgPrice;
                            const pnl = (p - h.avgPrice) * h.qty;
                            return (
                              <div key={t} className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0">
                                <div>
                                  <span className="font-semibold text-sm">{t}</span>
                                  <span className="text-[10px] text-gray-400 ml-2">×{h.qty}</span>
                                </div>
                                <div className={`font-mono text-sm font-medium ${pnl >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                                  {pnl >= 0 ? '+' : ''}{inr(pnl)}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'chart' && (
                <motion.div 
                  key="chart"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium flex items-center gap-2">
                      <ChartIcon size={18} className="text-blue-500" />
                      {selectedTicker} Chart
                    </h2>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => openOW(selectedTicker, 'buy')}
                        className="bg-[#26a69a] text-white px-4 py-1.5 rounded text-xs font-bold hover:brightness-110"
                      >
                        Buy {selectedTicker}
                      </button>
                      <button 
                        onClick={() => openOW(selectedTicker, 'sell')}
                        className="bg-[#ef5350] text-white px-4 py-1.5 rounded text-xs font-bold hover:brightness-110"
                      >
                        Sell {selectedTicker}
                      </button>
                    </div>
                  </div>
                  <div className="flex-1 bg-white border border-[#e8e8e8] rounded-lg overflow-hidden shadow-sm min-h-[500px]">
                    <TradingViewChart symbol={selectedTicker} />
                  </div>
                </motion.div>
              )}

              {activePage === 'orders' && (
                <motion.div 
                  key="orders"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-4"
                >
                  <h2 className="text-lg font-medium flex items-center gap-3">
                    Orders
                    <span className="text-[10px] font-mono bg-gray-100 px-2 py-0.5 rounded text-gray-500 uppercase">
                      {isSimulating ? 'Simulation' : 'Live Data'}
                    </span>
                  </h2>
                  <div className="bg-white border border-[#e8e8e8] rounded-lg overflow-hidden shadow-sm">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#f9f9f9] border-b border-[#e8e8e8]">
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Type</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Stock</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Qty</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Price</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Product</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Status</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Time</th>
                        </tr>
                      </thead>
                      <tbody className="text-[13px] font-mono">
                        {orders.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-10 text-center text-gray-400 font-sans">No orders yet.</td>
                          </tr>
                        ) : (
                          orders.map(o => (
                            <tr key={o.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${o.mode === 'BUY' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                                  {o.mode}
                                </span>
                              </td>
                              <td className="p-3 font-sans font-semibold">{o.t}</td>
                              <td className="p-3">{o.qty}</td>
                              <td className="p-3">₹{o.p.toFixed(2)}</td>
                              <td className="p-3">{o.prod}</td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded text-[10px] bg-blue-50 text-blue-600 font-bold">
                                  {o.status}
                                </span>
                              </td>
                              <td className="p-3 text-[#7c7c7c]">{new Date(o.time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activePage === 'holdings' && (
                <motion.div 
                  key="holdings"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-4"
                >
                  <h2 className="text-lg font-medium">Holdings</h2>
                  <div className="flex gap-4 bg-white border border-[#e8e8e8] rounded-lg p-4 shadow-sm">
                    <div className="flex-1">
                      <div className="text-[10px] text-[#7c7c7c] uppercase mb-1">Current Value</div>
                      <div className="text-xl font-mono font-medium">{inr(Object.keys(holdings).reduce((a: number, t: string) => a + holdings[t].qty * (prices[t] || holdings[t].avgPrice), 0))}</div>
                    </div>
                    <div className="w-px bg-gray-100" />
                    <div className="flex-1">
                      <div className="text-[10px] text-[#7c7c7c] uppercase mb-1">Invested</div>
                      <div className="text-xl font-mono font-medium">{inr((Object.values(holdings) as Holding[]).reduce((a, h) => a + h.qty * h.avgPrice, 0))}</div>
                    </div>
                    <div className="w-px bg-gray-100" />
                    <div className="flex-1">
                      <div className="text-[10px] text-[#7c7c7c] uppercase mb-1">Total P&L</div>
                      <div className={`text-xl font-mono font-medium ${unrealised >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                        {unrealised >= 0 ? '+' : ''}{inr(unrealised)}
                      </div>
                    </div>
                  </div>
                  <div className="bg-white border border-[#e8e8e8] rounded-lg overflow-hidden shadow-sm">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#f9f9f9] border-b border-[#e8e8e8]">
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Stock</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Qty</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Avg Cost</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">LTP</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">P&L</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="text-[13px] font-mono">
                        {Object.keys(holdings).length === 0 ? (
                          <tr>
                            <td colSpan={6} className="p-10 text-center text-gray-400 font-sans">No holdings yet.</td>
                          </tr>
                        ) : (
                          Object.keys(holdings).map(t => {
                            const h = holdings[t];
                            const p = prices[t] || h.avgPrice;
                            const pnl = (p - h.avgPrice) * h.qty;
                            const pct = ((p - h.avgPrice) / h.avgPrice * 100).toFixed(2);
                            return (
                              <tr key={t} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                                <td className="p-3 font-sans font-semibold">{t}</td>
                                <td className="p-3">{h.qty}</td>
                                <td className="p-3">₹{h.avgPrice.toFixed(2)}</td>
                                <td className="p-3">₹{p.toFixed(2)}</td>
                                <td className={`p-3 ${pnl >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                                  {pnl >= 0 ? '+' : ''}{inr(pnl)}
                                  <div className="text-[10px] opacity-70">{pnl >= 0 ? '+' : ''}{pct}%</div>
                                </td>
                                <td className="p-3">
                                  <div className="flex gap-2">
                                    <button onClick={() => openOW(t, 'buy')} className="text-[10px] font-bold text-emerald-600 hover:underline">BUY</button>
                                    <button onClick={() => openOW(t, 'sell')} className="text-[10px] font-bold text-rose-600 hover:underline">SELL</button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activePage === 'positions' && (
                <motion.div 
                  key="positions"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-4"
                >
                  <h2 className="text-lg font-medium">Positions</h2>
                  <div className="bg-white border border-[#e8e8e8] rounded-lg overflow-hidden shadow-sm">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#f9f9f9] border-b border-[#e8e8e8]">
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Product</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Stock</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Qty</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">Avg Price</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">LTP</th>
                          <th className="p-3 text-[10px] font-semibold text-[#7c7c7c] uppercase tracking-wider">P&L</th>
                        </tr>
                      </thead>
                      <tbody className="text-[13px] font-mono">
                        {Object.keys(holdings).length === 0 ? (
                          <tr>
                            <td colSpan={6} className="p-10 text-center text-gray-400 font-sans">No open positions.</td>
                          </tr>
                        ) : (
                          Object.keys(holdings).map(t => {
                            const h = holdings[t];
                            const p = prices[t] || h.avgPrice;
                            const pnl = (p - h.avgPrice) * h.qty;
                            return (
                              <tr key={t} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                                <td className="p-3 font-sans">CNC</td>
                                <td className="p-3 font-sans font-semibold">{t}</td>
                                <td className="p-3">{h.qty}</td>
                                <td className="p-3">₹{h.avgPrice.toFixed(2)}</td>
                                <td className="p-3">₹{p.toFixed(2)}</td>
                                <td className={`p-3 ${pnl >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                                  {pnl >= 0 ? '+' : ''}{inr(pnl)}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activePage === 'funds' && (
                <motion.div 
                  key="funds"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="max-w-4xl space-y-6"
                >
                  <h2 className="text-lg font-medium">Funds</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-6 shadow-sm space-y-6">
                      <div className="space-y-1">
                        <div className="text-xs text-[#7c7c7c] uppercase font-bold tracking-wider">Available Margin</div>
                        <div className="text-4xl font-light font-mono text-emerald-600">{inr(cash, 0)}</div>
                      </div>
                      
                      <div className="space-y-3 pt-4 border-t border-gray-50">
                        <div className="flex justify-between text-sm">
                          <span className="text-[#7c7c7c]">Opening balance</span>
                          <span className="font-mono font-medium">₹5,00,000.00</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-[#7c7c7c]">Margins used</span>
                          <span className="font-mono font-medium">{inr((Object.values(holdings) as Holding[]).reduce((a, h) => a + h.qty * h.avgPrice, 0))}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-[#7c7c7c]">Payin</span>
                          <span className="font-mono font-medium text-emerald-600">₹0.00</span>
                        </div>
                        <div className="flex justify-between text-sm font-bold pt-2 border-t border-gray-50">
                          <span>Total available</span>
                          <span className="font-mono">{inr(cash)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-6 shadow-sm space-y-4">
                      <h3 className="text-sm font-bold uppercase tracking-wider text-[#7c7c7c]">Add Simulated Funds</h3>
                      <p className="text-xs text-gray-500 leading-relaxed">
                        This is a paper trading app. You can add virtual money to your account to practice trading with larger capital.
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        {[10000, 50000, 100000, 500000].map(amt => (
                          <button
                            key={amt}
                            onClick={() => {
                              setCash(prev => prev + amt);
                              addNotif('Funds Added', `Successfully added ${inr(amt)} to your account.`);
                            }}
                            className="py-2 border border-gray-200 rounded text-xs font-bold hover:bg-gray-50 hover:border-emerald-500 hover:text-emerald-600 transition-all"
                          >
                            + {inr(amt, 0)}
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={() => {
                          setCash(500000);
                          addNotif('Account Reset', 'Your capital has been reset to ₹5,00,000.');
                        }}
                        className="w-full py-2 bg-gray-100 text-gray-600 rounded text-xs font-bold hover:bg-gray-200 transition-all"
                      >
                        Reset to ₹5 Lakhs
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'setup' && (
                <motion.div 
                  key="setup"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="max-w-2xl space-y-6"
                >
                  <h2 className="text-lg font-medium flex items-center gap-2">
                    <Settings size={18} className="text-orange-500" />
                    Live Data Setup
                  </h2>
                  
                  <div className="bg-orange-50 border border-orange-100 rounded-lg p-5 space-y-3">
                    <div className="flex items-center gap-2 text-orange-700 font-semibold text-sm">
                      <Info size={16} />
                      Live Market API Key
                    </div>
                    <p className="text-xs text-orange-600 leading-relaxed">
                      To get real-time market data, you can provide an API key from a supported provider. 
                      Currently, we support Alpha Vantage for global/simulated data. 
                      For NSE specific data, we recommend using Upstox or ICICI Breeze APIs.
                    </p>
                  </div>

                  <div className="bg-white border border-[#e8e8e8] rounded-lg p-6 space-y-4 shadow-sm">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-[#7c7c7c] uppercase tracking-wider">API Provider</label>
                      <select 
                        value={apiProvider}
                        onChange={(e) => setApiProvider(e.target.value)}
                        className="w-full p-2 border border-gray-200 rounded text-sm outline-none focus:border-blue-500"
                      >
                        <option>Alpha Vantage (Global)</option>
                        <option>Marketstack</option>
                        <option>Upstox (NSE)</option>
                        <option>ICICI Breeze (NSE)</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-[#7c7c7c] uppercase tracking-wider">API Key</label>
                      <div className="flex gap-2">
                        <input 
                          type="password" 
                          value={apiKey}
                          onChange={(e) => setApiKey(e.target.value)}
                          placeholder="Paste your API key here..."
                          className="flex-1 p-2 border border-gray-200 rounded text-sm font-mono outline-none focus:border-blue-500"
                        />
                        <button 
                          onClick={handleSaveKey}
                          disabled={isSavingKey || !apiKey}
                          className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isSavingKey ? 'Saving...' : 'Save Key'}
                        </button>
                      </div>
                      <p className="text-[10px] text-gray-400">Your key is used to fetch real-time data from the server.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-4 space-y-2">
                      <div className="text-xs font-bold text-emerald-600">FREE OPTION</div>
                      <div className="text-sm font-semibold">Simulation Mode</div>
                      <p className="text-[11px] text-gray-500">Realistic price movement based on historical volatility. No internet required.</p>
                      <button 
                        onClick={() => { setIsSimulating(true); addNotif('Simulation Active', 'Using realistic price simulation'); }}
                        className="w-full py-1.5 border border-emerald-200 text-emerald-600 rounded text-xs font-medium hover:bg-emerald-50"
                      >
                        Enable Simulation
                      </button>
                    </div>
                    <div className="bg-white border border-[#e8e8e8] rounded-lg p-4 space-y-2">
                      <div className="text-xs font-bold text-blue-600">REAL-TIME</div>
                      <div className="text-sm font-semibold">Broker API</div>
                      <p className="text-[11px] text-gray-500">Connect to Upstox or ICICI for true real-time NSE data and F&O support.</p>
                      <button 
                        onClick={() => window.open('https://upstox.com/developer/api-documentation/', '_blank')}
                        className="w-full py-1.5 border border-blue-200 text-blue-600 rounded text-xs font-medium hover:bg-blue-50"
                      >
                        Get Broker API
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* --- Order Window Overlay --- */}
      <AnimatePresence>
        {owTicker && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/10 z-[100] flex items-end justify-center sm:items-center sm:justify-start sm:pl-[280px]"
            onClick={() => setOwTicker(null)}
          >
            <motion.div 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="bg-white w-full max-w-[420px] rounded-t-xl sm:rounded-xl shadow-2xl border border-gray-200 overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-3 border-b border-gray-100 flex items-center justify-between">
                <div className="flex gap-1">
                  <button 
                    onClick={() => setOwMode('buy')}
                    className={`px-4 py-1.5 rounded text-sm font-bold transition-colors ${owMode === 'buy' ? 'bg-[#26a69a] text-white' : 'text-gray-400 hover:bg-gray-50'}`}
                  >
                    Buy
                  </button>
                  <button 
                    onClick={() => setOwMode('sell')}
                    className={`px-4 py-1.5 rounded text-sm font-bold transition-colors ${owMode === 'sell' ? 'bg-[#ef5350] text-white' : 'text-gray-400 hover:bg-gray-50'}`}
                  >
                    Sell
                  </button>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold">{owTicker}</div>
                  <div className="text-[10px] text-gray-400 font-mono">NSE · LTP ₹{(prices[owTicker] || 0).toFixed(2)}</div>
                </div>
                <button onClick={() => setOwTicker(null)} className="text-gray-400 hover:text-gray-600">
                  <X size={20} />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Order Type</label>
                    <select 
                      value={owType}
                      onChange={(e) => setOwType(e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded text-sm outline-none focus:border-blue-500"
                    >
                      <option>Market</option>
                      <option>Limit</option>
                      <option>SL</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Product</label>
                    <select 
                      value={owProd}
                      onChange={(e) => setOwProd(e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded text-sm outline-none focus:border-blue-500"
                    >
                      <option value="CNC">CNC (Delivery)</option>
                      <option value="MIS">MIS (Intraday)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Qty</label>
                    <input 
                      type="number" 
                      value={owQty}
                      onChange={(e) => setOwQty(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full p-2 border border-gray-200 rounded text-sm font-mono outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Price</label>
                    <input 
                      type="number" 
                      value={owType === 'Market' ? (prices[owTicker] || 0).toFixed(2) : owPrice}
                      disabled={owType === 'Market'}
                      onChange={(e) => setOwPrice(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 border border-gray-200 rounded text-sm font-mono outline-none focus:border-blue-500 disabled:bg-gray-50 disabled:text-gray-400"
                    />
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-3 flex justify-between items-center text-xs">
                  <div className="text-gray-500">Approx. Required</div>
                  <div className="font-mono font-bold text-sm">
                    {inr(owQty * (owType === 'Market' ? (prices[owTicker] || 0) : owPrice))}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button 
                    onClick={submitOrder}
                    className={`flex-1 py-2.5 rounded-lg text-white font-bold text-sm shadow-lg shadow-black/5 transition-transform active:scale-[0.98] ${owMode === 'buy' ? 'bg-[#26a69a]' : 'bg-[#ef5350]'}`}
                  >
                    {owMode === 'buy' ? 'BUY' : 'SELL'}
                  </button>
                  <button 
                    onClick={() => setOwTicker(null)}
                    className="px-6 py-2.5 border border-gray-200 rounded-lg text-gray-500 font-medium text-sm hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Notifications --- */}
      <div className="fixed top-12 right-4 z-[200] flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {notifs.map(n => (
            <motion.div
              key={n.id}
              initial={{ x: 300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 300, opacity: 0 }}
              className={`w-72 bg-white border border-gray-100 rounded-lg p-3 shadow-xl pointer-events-auto flex gap-3 ${n.type === 'error' ? 'border-l-4 border-l-rose-500' : 'border-l-4 border-l-emerald-500'}`}
            >
              <div className="mt-0.5">
                {n.type === 'error' ? <AlertCircle size={16} className="text-rose-500" /> : <CheckCircle2 size={16} className="text-emerald-500" />}
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-gray-900">{n.title}</div>
                <div className="text-[11px] text-gray-500 mt-0.5 leading-tight">{n.body}</div>
              </div>
              <button onClick={() => setNotifs(prev => prev.filter(x => x.id !== n.id))} className="text-gray-300 hover:text-gray-500">
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
