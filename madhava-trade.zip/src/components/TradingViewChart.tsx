import React, { memo } from 'react';

interface TradingViewChartProps {
  symbol: string;
}

const TradingViewChart: React.FC<TradingViewChartProps> = ({ symbol }) => {
  // Construct the iframe URL for the Advanced Chart widget
  // Using the iframe approach is often more reliable in sandboxed environments
  // and can sometimes bypass symbol restrictions seen in the JS-injected version.
  const formattedSymbol = symbol.toUpperCase();
  
  // We use BSE as it often has fewer embedding restrictions for Indian stocks in free widgets
  // compared to NSE which can sometimes be blocked in certain iframe environments.
  const chartUrl = `https://s.tradingview.com/widgetembed/?symbol=BSE:${formattedSymbol}&interval=D&hidesidetoolbar=0&hidetoptoolbar=0&symboledit=1&saveimage=1&toolbarbg=f1f3f6&theme=light&style=1&timezone=Asia%2FKolkata&withdateranges=1&studies=[]&locale=en&utm_source=localhost&utm_medium=widget&utm_campaign=chart`;

  return (
    <div className="w-full h-full bg-white">
      <iframe
        id={`tradingview_${formattedSymbol.toLowerCase()}`}
        name={`tradingview_${formattedSymbol.toLowerCase()}`}
        src={chartUrl}
        style={{ width: '100%', height: '100%', border: 'none' }}
        allowFullScreen
        title={`TradingView Chart for ${formattedSymbol}`}
        referrerPolicy="no-referrer"
      />
    </div>
  );
};

export default memo(TradingViewChart);
